package deleteslll;

public class SinglyLinkedListOperation implements SinglyLinkedList {
	Node head = null;
	Node tail = null;

	@Override
	public void addatFirst(int data) {
		Node node = new Node();
		if (head == null) {
			System.out.println("LinkedList is Empty!!");
			node.data = data;
			node.next = null;
			head = node;
		} else {
			node.data = data;
			node.next = head;
			head = node;

		}
		if (node.next == null) {
			tail = node;
		}

	}

	@Override
	public void addatMiddle(int index, int data) {
		Node node = new Node();
		Node temp = head;
		for (int i = 0; i < index - 1 && temp != null; i++) {
			temp = temp.next;
		}
		node.data = data;
		node.next = temp.next;
		temp.next = node;
		if (node.next == null) {
			tail = node;
		}
	}
	@Override
	public void addatLast(int data) {
		Node node = new Node();
		if (head == null) {
			System.out.println("Linked List is Empty first add at first position");
		} else {
			node.data = data;
			tail.next = node;
			node.next = null;
		}
		if (node.next == null) {
			tail = node;
		}
	}

	@Override
	public void deleteatFirst() {
		if (head == null) {
			System.out.println("LinkeList is already Empty");
		} else {
			head = head.next;
		}
		if (head.next == null && head != null) {
			tail = head;
		}

	}

	@Override
	public void deleteatMiddle(int index) {
		if (index == 0) {
			head = head.next;
		}
		if (head == null) {
			System.out.println("LinkedLsit is empty! pls addatFirst");
		} else {
			Node temp = head;
			for (int i = 0; i < index - 1 && temp != null; i++) {
				temp = temp.next;
			}
			if (temp.next == null) {
				System.out.println("your are in last position try with deleteat last");
			}
			temp.next = temp.next.next;
		}
	}

	@Override
	public void deleteatLast() {
		Node temp = head;
		while (temp.next.next != null) {
			temp = temp.next;
		}
		temp.next = null;
		tail = temp;
	}
	public void display() {
		Node temp = head;
		while (temp != null) {
			System.out.println(temp.data);
			temp = temp.next;
		}
	}
}
