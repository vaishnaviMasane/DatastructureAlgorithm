package deleteslll;

import com.addslll.SinglylLinkedListImplementation;

public class Main {

	public static void main(String[] args) {
	SinglyLinkedListOperation sl=new SinglyLinkedListOperation();
	sl.addatFirst(10);
	sl.addatMiddle(1, 20);
	sl.addatMiddle(2, 30);
	sl.addatLast(50);
	sl.addatMiddle(3, 40);
	sl.display();
	sl.deleteatFirst();
	System.out.println("------");
	sl.display();
	sl.deleteatMiddle(3);
	System.out.println("delete 50");
	sl.display();
    
	}

}
