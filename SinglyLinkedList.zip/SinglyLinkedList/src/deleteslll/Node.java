package deleteslll;

public class Node {
int data;
Node next;
}
