package deleteslll;

public interface SinglyLinkedList {
void addatFirst(int data);
void addatMiddle(int index, int data);
void addatLast(int data);
void deleteatFirst();
void deleteatMiddle(int index);
void deleteatLast();
}
