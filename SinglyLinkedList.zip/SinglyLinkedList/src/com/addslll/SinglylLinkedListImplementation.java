package com.addslll;

public class SinglylLinkedListImplementation implements SinglyLinkedList{
Node head=null;
Node tail=head;

	@Override
	public void addatFirst(int data) {
		Node node=new Node();
		if(head==null)
		{
			System.out.println("head is empty! head==null");
			
			node.data=data;
			node.next=null;
			head=node;
			tail=node;
			
			System.out.println("successfully added in first position!!");
		}
		if(node.next==null)
		{
			tail=node;
		}
		
	}

	@Override
	public void addatmiddle(int index,int data) {
		Node node=new Node();
		if(head==null)
		{
			System.out.println("head is empty!! Your need to add at First position!");
		}
		else {
			Node temp=head;
			for(int i=0;i<index-1&&temp!=null; i++)
			{
				temp=temp.next;
				
			}
			
			node.data=data;
			node.next=temp.next;
			temp.next=node;
		
		}
		if(node.next==null)
		{
			tail=node;
		}
		
	}

	@Override
	public void addatlast(int data) {
		Node node =new Node();
		if(head==null)
		{
			System.out.println("Linkedlist is empty!! add at First position");
			
		}
		else
		{
			
			node.data=data;
			node.next=null;
			tail.next=node;
			tail=node;
			
		}
		
	}
	public void display()
	{
		Node temp=head;
		while(temp!=null)
		{
		System.out.println(temp.data);
		temp=temp.next;
		}
	}

}
