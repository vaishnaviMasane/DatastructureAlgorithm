package com.addslll;

public interface SinglyLinkedList {
void addatFirst(int data);
void addatmiddle(int index,int data);
void addatlast(int data);


}
