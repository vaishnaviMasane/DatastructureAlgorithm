package com.addslll;

public class Node {
int data;
Node next;
}
