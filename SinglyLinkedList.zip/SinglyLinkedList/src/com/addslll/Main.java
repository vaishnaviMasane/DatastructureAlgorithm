package com.addslll;

public class Main {

	public static void main(String[] args) {
		SinglylLinkedListImplementation sl=new SinglylLinkedListImplementation();
		sl.addatFirst(10);
		sl.addatmiddle(1, 20);
		sl.addatmiddle(2, 40);
		sl.addatmiddle(3, 30);
	    sl.addatmiddle(2, 6);
	    
		sl.addatlast(50);
		sl.addatmiddle(4, 90);
		sl.display();
		
	}

}
