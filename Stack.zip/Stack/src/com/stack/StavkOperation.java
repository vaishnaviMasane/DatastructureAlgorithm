package com.stack;

public interface StavkOperation {
void push(int element);
void pop();
void peek();
boolean isEmpty();
boolean isFull();

}
