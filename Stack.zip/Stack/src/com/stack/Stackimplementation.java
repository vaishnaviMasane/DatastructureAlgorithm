package com.stack;



public class Stackimplementation implements StavkOperation {
int top=-1;
int size;
int stack[];
public Stackimplementation(int size)
{
	this.size=size;
	stack=new int[size];
}

  


@Override
public void push(int element) {
	if(isFull())
	{
		top++;
		stack[top]=element;
		System.out.println(stack[top]+ "Push element!");
	}
}

@Override
public void pop() {
	if(isEmpty())
	{
		top--;
		System.out.println(stack[top]+ "Pop Element!!");
	}
	
}

@Override
public void peek() {
	System.out.println(stack[top]);
	
}

@Override
public boolean isEmpty() {
	if(top!=-1)
	{
		return true;
	}
	else {
		return false;
	}
}

@Override
public boolean isFull() {
	if(top!=size-1)
	{
		return true;
	}
	else {
		return false;
	}
	
}

}
