package com.stack;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
  
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size of Array!!");
		int size=sc.nextInt();
		sc.nextLine();
		Stackimplementation st=new Stackimplementation(size);
		st.isEmpty();
		st.isFull();
		st.push(10);
		st.push(20);
		st.push(30);
		st.push(40);
		st.push(50);
	
		st.pop();
		st.peek();
	}
	

}
